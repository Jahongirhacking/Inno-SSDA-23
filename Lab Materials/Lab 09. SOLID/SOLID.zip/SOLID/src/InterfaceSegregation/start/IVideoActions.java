package InterfaceSegregation.start;

public interface IVideoActions {

    double getNumberOfHoursPlayed();

    void playRandomAdvert() throws Exception;
}
