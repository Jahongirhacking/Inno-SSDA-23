package InterfaceSegregation.end;

import java.util.ArrayList;
import java.util.List;

/* GOAL: Clients should not be forced to depend on methods
 * that they do not use
 */

/*
 * Reasoning:
 * Dividing "fat" interfaces into small precise interfaces helps us satisfy the
 * ISP as clients implement only what they absolutely need
 * This is another way of addressing the issue we encountered in LSP
 * */

public class Runner {
    public static void main(String[] args) {

        List<IAdsActions> videos = new ArrayList<>();
        videos.add(new Video());
        videos.add(new Video());

        for (IAdsActions video : videos) {
            video.playRandomAdvert();
        }
    }
}
