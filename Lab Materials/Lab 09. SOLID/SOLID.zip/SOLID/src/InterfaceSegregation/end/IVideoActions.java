package InterfaceSegregation.end;

public interface IVideoActions {
    double getNumberOfHoursPlayed();
}
