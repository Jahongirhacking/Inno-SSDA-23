package InterfaceSegregation.end;

public class Video implements IVideoActions, IAdsActions {
    private double duration;
    private int numberOfViews;

    @Override
    public void playRandomAdvert() {
        /* play an advert*/
        System.out.println("Playing Advert");
    }

    @Override
    public double getNumberOfHoursPlayed() {
        return (duration / 3600.0) * numberOfViews;
    }
}
