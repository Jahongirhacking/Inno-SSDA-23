package InterfaceSegregation.end;

public interface IAdsActions {


    void playRandomAdvert();
}
