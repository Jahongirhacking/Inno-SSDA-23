package InterfaceSegregation.end;

public class PremiumVideo implements IVideoActions {
    private double duration;
    private int numberOfViews;
    

    @Override
    public double getNumberOfHoursPlayed() {
        return (duration / 3600.0) * numberOfViews;
    }
}
