package LiskovSubstitution.end;

public class PremiumVideo {
    private int premiumId;
    private final VideoManager manager;

    public PremiumVideo(VideoManager manager) {
        this.manager = manager;
    }

    public double getNumberOfHoursPlayed() {
        return manager.getNumberOfHoursPlayed();
    }

}
