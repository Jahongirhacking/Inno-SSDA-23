package LiskovSubstitution.end;

public class Video {
    private final VideoManager manager;

    public Video(VideoManager manager) {
        this.manager = manager;
    }

    public double getNumberOfHoursPlayed() {
        return manager.getNumberOfHoursPlayed();
    }

    public void playRandomAdvert() {
        manager.playRandomAdvert();
    }
}
