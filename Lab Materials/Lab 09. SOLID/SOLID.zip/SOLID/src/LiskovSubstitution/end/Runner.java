package LiskovSubstitution.end;

import java.util.ArrayList;
import java.util.List;

/* GOAL: A variable of a given type may be assigned a value of
 * any subtype of that type
 */

/*
 * Reasoning:
 * VideoManager contains all the functions that comes with Videos,
 * We can then use composition by adding VideoManager into both
 * Video and PremiumVideo Classes.
 * By doing so, Video and PremiumVideo classes can choose the
 * functionality of VideoManager they need in other to work properly.
 * This would result in code that is easier to understand, modify, and maintain.
 *
 * There are generally 2 ways of addressing this issue.
 * 1. ISP can be used to make sure a class satisfies the LSP
 * 2. Choosing Composition over inheritance
 */

public class Runner {
    public static void main(String[] args) throws Exception {

        List<Video> videos = new ArrayList<>();
        VideoManager manager = new VideoManager();

        videos.add(new Video(manager));
        videos.add(new Video(manager));

        for (Video video : videos) {
            video.playRandomAdvert();
        }
    }
}
