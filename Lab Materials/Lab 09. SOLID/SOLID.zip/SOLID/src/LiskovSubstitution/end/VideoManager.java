package LiskovSubstitution.end;

public class VideoManager {
    private double duration;
    private int numberOfViews;

    public double getNumberOfHoursPlayed() {
        return (duration / 3600.0) * numberOfViews;
    }

    public void playRandomAdvert() {
        /* play an advert*/
        System.out.println("Playing Advert");
    }
}
