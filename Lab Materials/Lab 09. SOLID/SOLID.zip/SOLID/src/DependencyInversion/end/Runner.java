package DependencyInversion.end;

import java.util.ArrayList;
import java.util.List;

/* GOAL:
 * Higher-level components shouldn't depend on lower-level
 * components. Both should depend on abstractions.
 * Abstractions shouldn't depend on details: details should
 * depend on abstractions
 */

/* Reasoning:
 * With Video depending on a VideoManager abstraction, we have
 * full flexibility and can pass in any type of VideoManager anywhere
 *  in our codebase without touching the Video class ever again.
 * */


public class Runner {
    public static void main(String[] args) {

        List<Video> videos = new ArrayList<>();
        YouTubeVideoManager manager = new YouTubeVideoManager();

        videos.add(new Video(manager));
        videos.add(new Video(manager));

        for (Video video : videos) {
            video.playRandomAdvert();
        }
    }
}
