package DependencyInversion.end;

public class TikTokVideoManager implements IVideoManager {
    private int duration;
    private int numberOfViews;

    @Override
    public double getNumberOfHoursPlayed() {

        return (duration / 36.0) * numberOfViews;
    }

    @Override
    public void playRandomAdvert() {
        /* play an advert from TikTok */
        System.out.println("Playing Advert from TikTok");
    }
}
