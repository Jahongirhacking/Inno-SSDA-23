package DependencyInversion.end;

public class YouTubeVideoManager implements IVideoManager {
    private double duration;
    private int numberOfViews;

    @Override
    public double getNumberOfHoursPlayed() {
        return (duration / 3600.0) * numberOfViews;
    }

    @Override
    public void playRandomAdvert() {
        /* play an advert from YouTube */
        System.out.println("Playing Advert from YouTube");
    }
}
