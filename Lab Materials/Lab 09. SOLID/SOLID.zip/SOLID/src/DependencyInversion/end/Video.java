package DependencyInversion.end;

public class Video {
    IVideoManager manager;

    public Video(IVideoManager manager) {
        this.manager = manager;
    }

    public double getNumberOfHoursPlayed() {
        return manager.getNumberOfHoursPlayed();
    }

    public void playRandomAdvert() {
        manager.playRandomAdvert();
    }
}
