package DependencyInversion.end;

public interface IVideoManager {

    double getNumberOfHoursPlayed();

    void playRandomAdvert();
}
