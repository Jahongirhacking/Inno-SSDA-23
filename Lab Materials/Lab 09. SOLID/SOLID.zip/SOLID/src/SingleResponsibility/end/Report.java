package SingleResponsibility.end;

/* GOAL: Each class should have only one sole purpose,
 * and not be filled with excessive functionality
 */

/*
 * Reasoning:
 * A better approach would be to separate the data processing and printing
 * functionality into two separate classes. One class could be responsible for
 * reading the data from the file, while another class could be responsible for
 * printing the data.
 * This would result in code that is easier to understand, modify, and maintain.
 */

public class Report {
    private final DataReader dataReader;
    private final DataPrinter dataPrinter;

    public Report(DataReader dataReader, DataPrinter dataPrinter) {
        this.dataReader = dataReader;
        this.dataPrinter = dataPrinter;
    }

    public void generateReport(String filename) {
        String data = dataReader.read(filename);
        dataPrinter.print(data);
    }
}

class Runner {
    public static void main(String[] args) {
        DataReader reader = new DataReader();
        DataPrinter printer = new DataPrinter();

        Report report = new Report(reader, printer);
        report.generateReport("sample_input_file");
    }
}