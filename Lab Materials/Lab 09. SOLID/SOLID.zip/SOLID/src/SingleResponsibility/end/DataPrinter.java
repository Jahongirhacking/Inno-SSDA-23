package SingleResponsibility.end;

public class DataPrinter {
    public void print(String data) {
        System.out.println(data);
    }
}