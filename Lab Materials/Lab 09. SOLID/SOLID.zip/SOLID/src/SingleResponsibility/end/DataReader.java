package SingleResponsibility.end;

public class DataReader {
    public String read(String filename) {
        /* Read data from the file */
        StringBuilder data = new StringBuilder();

        /* Opening and reading the file until EOF */
        data.append("Empty string");

        return data.toString();
    }
}
