package OpenClosed.start;

public class Runner {
    public static void main(String[] args) {
        FileGenerator generator = new FileGenerator();
        generator.generatePDF("\nMy data to be converted to PDF format start\n");
    }
}
