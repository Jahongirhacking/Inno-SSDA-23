package OpenClosed.end;

public class RTFOutput implements IOutputFormat {
    @Override
    public void generate(String data) {
        System.out.println("Generating RTF from " + data);
    }
}
