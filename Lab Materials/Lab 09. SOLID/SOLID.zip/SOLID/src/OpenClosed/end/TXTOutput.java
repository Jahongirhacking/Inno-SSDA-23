package OpenClosed.end;

public class TXTOutput implements IOutputFormat {
    @Override
    public void generate(String data) {
        System.out.println("Generating TXT from " + data);
    }
}
