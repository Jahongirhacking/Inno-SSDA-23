package OpenClosed.end;

public interface IOutputFormat {
    void generate(String data);
}
