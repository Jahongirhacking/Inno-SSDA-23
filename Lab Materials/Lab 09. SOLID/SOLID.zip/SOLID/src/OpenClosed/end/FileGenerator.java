package OpenClosed.end;

public class FileGenerator {

    public void generate(String data, IOutputFormat outputFormat) {
        outputFormat.generate(data);
    }
}
