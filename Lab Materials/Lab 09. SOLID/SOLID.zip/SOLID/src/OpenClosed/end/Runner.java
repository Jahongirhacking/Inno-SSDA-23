package OpenClosed.end;

/* GOAL:
 * Components should be open for extension,
 * closed for modification
 */

/*
 * Reasoning:
 * Currently, you never have to modify the FileGenerator Class in order for it
 * to support generating other file types. (Closed for modification)
 * Instead, you can create a new class with the specific file type you
 * wish to support and implement the IOutputFormat interface. (Open for extension)
 * This would result in code that is easier to understand, modify, and maintain.
 * In some cases, DIP can be used to make sure a class satisfies the OCP
 */

public class Runner {
    public static void main(String[] args) {
        FileGenerator generator = new FileGenerator();
        IOutputFormat outputFormat = new PDFOutput();

        generator.generate("\nMy data to be converted to PDF format end\n", outputFormat);
    }
}
