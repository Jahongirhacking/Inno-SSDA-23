public interface ITransportFactory {
    ITransport createTransport();
}
