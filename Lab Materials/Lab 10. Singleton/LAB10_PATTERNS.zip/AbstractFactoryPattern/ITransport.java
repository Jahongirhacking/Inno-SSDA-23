public interface ITransport {
    public void deliver();
}
