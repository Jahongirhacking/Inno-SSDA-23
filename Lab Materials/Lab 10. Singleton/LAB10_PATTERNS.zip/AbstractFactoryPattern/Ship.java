public class Ship implements ITransport{
    @Override
    public void deliver() {
        System.out.println("Doing delivery through the seas!!");
    }
}
