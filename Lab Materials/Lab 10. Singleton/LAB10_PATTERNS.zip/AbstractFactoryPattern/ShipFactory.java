public class ShipFactory implements ITransportFactory{
    @Override
    public ITransport createTransport() {
        return new Ship();
    }
}
