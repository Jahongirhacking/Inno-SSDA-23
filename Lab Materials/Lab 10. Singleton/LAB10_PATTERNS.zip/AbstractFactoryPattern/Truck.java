public class Truck implements ITransport{
    @Override
    public void deliver() {
        System.out.println("Doing delivery locally!");
    }
}
