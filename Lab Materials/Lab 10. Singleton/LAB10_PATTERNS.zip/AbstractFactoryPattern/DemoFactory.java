public class DemoFactory {

    public static void main(String[] args) {
        // create concrete instances of factory
        ITransportFactory shipfactory = new ShipFactory();
        ITransport transport = shipfactory.createTransport();
        transport.deliver();

    }
}
