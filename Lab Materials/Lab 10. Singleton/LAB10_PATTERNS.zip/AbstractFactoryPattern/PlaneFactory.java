public class PlaneFactory implements ITransportFactory{
    @Override
    public ITransport createTransport() {
        return new Plane();
    }
}
