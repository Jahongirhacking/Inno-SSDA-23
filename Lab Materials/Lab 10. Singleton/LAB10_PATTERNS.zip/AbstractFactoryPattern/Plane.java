public class Plane implements ITransport{

    @Override
    public void deliver() {
        System.out.println("Doing delivery through the sky!");
    }
}
