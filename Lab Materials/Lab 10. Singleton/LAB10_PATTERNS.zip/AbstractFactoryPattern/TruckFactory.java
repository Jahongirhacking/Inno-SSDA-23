public class TruckFactory implements ITransportFactory{
    @Override
    public ITransport createTransport() {
        return new Truck();
    }
}
