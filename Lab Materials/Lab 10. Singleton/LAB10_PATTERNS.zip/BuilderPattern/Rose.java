public class Rose {
}
