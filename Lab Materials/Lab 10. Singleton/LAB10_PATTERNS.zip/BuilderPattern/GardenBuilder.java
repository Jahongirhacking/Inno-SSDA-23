import java.util.List;

public class GardenBuilder {
    List<Sakura> sakuraTrees;
    List<Oak> oakTrees;
    List<Orchid> orchidFlowers;
    List<Rose> roses;
    List<Bench> benches;
    Lake lake;
    double perimeter;
    double surface;

    public GardenBuilder setSakuraTrees(List<Sakura> sakuraTrees) {
        this.sakuraTrees = sakuraTrees;
        return this;
    }

    public GardenBuilder setOakTrees(List<Oak> oakTrees) {
        this.oakTrees = oakTrees;
        return this;
    }

    public GardenBuilder setOrchidFlowers(List<Orchid> orchidFlowers) {
        this.orchidFlowers = orchidFlowers;
        return this;
    }

    public GardenBuilder setRoses(List<Rose> roses) {
        this.roses = roses;
        return this;
    }

    public GardenBuilder setBenches(List<Bench> benches) {
        this.benches = benches;
        return this;
    }

    public GardenBuilder setLake(Lake lake) {
        this.lake = lake;
        return this;
    }

    public GardenBuilder setPerimeter(double perimeter) {
        this.perimeter = perimeter;
        return this;
    }

    public GardenBuilder setSurface(double surface) {
        this.surface = surface;
        return this;
    }

    public Garden build() {
        return new Garden(this);
    }

}
