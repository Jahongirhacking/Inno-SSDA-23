public class Sakura {
}
