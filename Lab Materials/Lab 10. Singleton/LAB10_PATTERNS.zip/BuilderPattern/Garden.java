import java.util.List;

public class Garden {
    private final List<Sakura> sakuraTrees;
    private final List<Oak> oakTrees;
    private final List<Orchid> orchidFlowers;
    private final List<Rose> roses;
    private final List<Bench> benches;
    private final Lake lake;
    private final double perimeter;
    private final double surface;

    public Garden(GardenBuilder builder) {
        this.sakuraTrees = builder.sakuraTrees;
        this.oakTrees = builder.oakTrees;
        this.orchidFlowers = builder.orchidFlowers;
        this.roses = builder.roses;
        this.benches = builder.benches;
        this.lake = builder.lake;
        this.perimeter = builder.perimeter;
        this.surface = builder.surface;
    }

    public List<Sakura> getSakuraTrees() {
        return sakuraTrees;
    }

    public List<Oak> getOakTrees() {
        return oakTrees;
    }

    public List<Orchid> getOrchidFlowers() {
        return orchidFlowers;
    }

    public List<Rose> getRoses() {
        return roses;
    }

    public List<Bench> getBenches() {
        return benches;
    }

    public Lake getLake() {
        return lake;
    }

    public double getPerimeter() {
        return perimeter;
    }

    public double getSurface() {
        return surface;
    }

    @Override
    public String toString() {
        return "Garden{" +
                "sakuraTrees=" + sakuraTrees +
                ", oakTrees=" + oakTrees +
                ", orchidFlowers=" + orchidFlowers +
                ", roses=" + roses +
                ", benches=" + benches +
                ", lake=" + lake +
                ", perimeter=" + perimeter +
                ", surface=" + surface+
                '}';}
}
