import java.util.ArrayList;
import java.util.List;
public class BuilderDemo {
    public static void main(String[] args) {
        List<Sakura> sakuraTrees = new ArrayList<>();
        sakuraTrees.add(new Sakura());
        sakuraTrees.add(new Sakura());

        List<Oak> oakTrees = new ArrayList<>();
        oakTrees.add(new Oak());
        oakTrees.add(new Oak());
        oakTrees.add(new Oak());

        List<Orchid> orchidFlowers = new ArrayList<>();
        orchidFlowers.add(new Orchid());
        orchidFlowers.add(new Orchid());
        List<Rose> roses = new ArrayList<>();
        roses.add(new Rose());
        roses.add(new Rose());
        roses.add(new Rose());
        roses.add(new Rose());
        roses.add(new Rose());
        roses.add(new Rose());


        List<Bench> benches = new ArrayList<>();
        benches.add(new Bench());
        benches.add(new Bench());

        Lake lake = new Lake(10.0);

        Garden garden = new GardenBuilder()
                .setSakuraTrees(sakuraTrees)
                .setOakTrees(oakTrees)
                .setOrchidFlowers(orchidFlowers)
                .setRoses(roses)
                .setBenches(benches)
                .setLake(lake)
                .setPerimeter(50.0)
                .setSurface(1000.0)
                .build();

        System.out.println(garden);
    }
}
