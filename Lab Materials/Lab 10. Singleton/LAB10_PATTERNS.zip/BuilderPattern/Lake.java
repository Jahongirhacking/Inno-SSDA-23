import java.util.List;

public class Lake {
    private  double perimeter;
    private  List<Integer> fish;

    public Lake(double perimeter) {
        this.perimeter = perimeter;
    }
}
