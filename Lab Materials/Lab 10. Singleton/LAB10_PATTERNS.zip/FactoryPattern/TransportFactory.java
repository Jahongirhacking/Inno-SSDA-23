public class TransportFactory {

    //use getTransport method to get object of type Transport
    public ITransport getTransport(String transportType){
        if(transportType == null){
            return null;
        }
        if(transportType.equalsIgnoreCase("TRUCK")){
            return new Truck();

        } else if(transportType.equalsIgnoreCase("SHIP")){
            return new Ship();

        } else if(transportType.equalsIgnoreCase("PLANE")){
            return new Plane();
        }

        return null;
    }
}
