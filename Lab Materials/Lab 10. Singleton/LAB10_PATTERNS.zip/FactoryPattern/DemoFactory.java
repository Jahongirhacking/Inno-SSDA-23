public class DemoFactory {

    public static void main(String[] args) {
        TransportFactory transportFactory = new TransportFactory();

        // we create a ship transport object
        ITransport transport1 = transportFactory.getTransport("SHIP");
        transport1.deliver();

        // we create a truck transport object
        ITransport transport2 = transportFactory.getTransport("Truck");
        transport2.deliver();

        // we create a plane transport object
        ITransport shape3 = transportFactory.getTransport("PLANE");
        shape3.deliver();
    }
}
